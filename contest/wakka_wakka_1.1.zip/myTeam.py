# myTeam.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
#
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


from captureAgents import CaptureAgent
import random, time, util
from game import Directions
import game

#################
# Team creation #
#################

from captureAgents import CaptureAgent
import distanceCalculator
import random, time, util, sys
from game import Directions
import game
from util import nearestPoint

DEBUG_SEED = random.randint(1, 5)

#################
# Team creation #
#################

def createTeam(firstIndex, secondIndex, isRed,
               first = 'OffensiveReflexAgent', second = 'DefensiveReflexAgent'):
  """
  This function should return a list of two agents that will form the
  team, initialized using firstIndex and secondIndex as their agent
  index numbers.  isRed is True if the red team is being created, and
  will be False if the blue team is being created.

  As a potentially helpful development aid, this function can take
  additional string-valued keyword arguments ("first" and "second" are
  such arguments in the case of this function), which will come from
  the --redOpts and --blueOpts command-line arguments to capture.py.
  For the nightly contest, however, your team will be created without
  any extra arguments, so you should make sure that the default
  behavior is what you want for the nightly contest.
  """
  print "SEED: " + str(DEBUG_SEED) + "\n"
  return [eval(first)(firstIndex), eval(second)(secondIndex)]

##########
# Agents #
##########

class ReflexCaptureAgent(CaptureAgent):
    """
    A base class for reflex agents that chooses score-maximizing actions
    """

    def registerInitialState(self, gameState):
        self.start = gameState.getAgentPosition(self.index)
        CaptureAgent.registerInitialState(self, gameState)

    #######################
    ### ADDED FUNCTIONS ###
    #######################
    def getLegalPositions(self, gameState):
        """
        Gets all valid positions on the grid where a pacman could
        legally be
        """
        legalPositions = []
        walls = gameState.getWalls()

        for x in range(walls.width):
            for y in range(walls.height):
                if not walls[x][y]:
                    legalPositions.append((x,y))
        return legalPositions

    def getEnemyNoisyDistances(self, gameState):
        """
        Gets the 'raw' noisy distances to each enemy (+/- 6)
        """
        noisyEnemyDists = []
        noisyDistances = gameState.getAgentDistances()
        for agent in self.getOpponents(gameState):
            noisyEnemyDists.append(noisyDistances[agent])
        return noisyEnemyDists

    ##########################
    ### STANDARD FUNCTIONS ###
    ##########################
    def chooseAction(self, gameState):
        """
        Picks among the actions with the highest Q(s,a).
        """
        actions = gameState.getLegalActions(self.index)

        # You can profile your evaluation time by uncommenting these lines
        # start = time.time()
        values = [self.evaluate(gameState, a) for a in actions]
        # print 'eval time for agent %d: %.4f' % (self.index, time.time() - start)

        maxValue = max(values)
        bestActions = [a for a, v in zip(actions, values) if v == maxValue]

        foodLeft = len(self.getFood(gameState).asList())

        if foodLeft <= 2:
            bestDist = 9999
            for action in actions:
                successor = self.getSuccessor(gameState, action)
                pos2 = successor.getAgentPosition(self.index)
                dist = self.getMazeDistance(self.start,pos2)
                if dist < bestDist:
                    bestAction = action
                    bestDist = dist
            return bestAction

        return random.choice(bestActions)

    def getSuccessor(self, gameState, action):
        """
        Finds the next successor which is a grid position (location tuple).
        """
        successor = gameState.generateSuccessor(self.index, action)
        pos = successor.getAgentState(self.index).getPosition()
        if pos != nearestPoint(pos):
            # Only half a grid position was covered
            return successor.generateSuccessor(self.index, action)
        else:
            return successor

    def evaluate(self, gameState, action):
        """
        Computes a linear combination of features and feature weights
        """
        features = self.getFeatures(gameState, action)
        weights = self.getWeights(gameState, action)

        return features * weights

    def getFeatures(self, gameState, action):
        """
        Returns a counter of features for the state
        """
        features = util.Counter()
        successor = self.getSuccessor(gameState, action)
        features['successorScore'] = self.getScore(successor)
        return features

    def getWeights(self, gameState, action):
        """
        Normally, weights do not depend on the gamestate.  They can be either
        a counter or a dictionary.
        """
        weights={
            'successorScore':1.0,
        }

        for key, value in weights.iteritems():
            weights[key] = value * DEBUG_SEED

        return weights


class OffensiveReflexAgent(ReflexCaptureAgent):
  """
  An offensive agent for use in the RMIT pacman AI competition
  @Author Liam - s3372913
  """
  def chooseAction(self, gameState):
    """
    NOTE: Modified from the original function provided in ReflexCaptureAgent.
    Would have liked to call super to prevent copying the code, but super calls in python aren't a good idea apparently.
    """
    actions = gameState.getLegalActions(self.index)

    # Track food held
    # We review our observation history to see changes in food over time.
    myPos = gameState.getAgentState(self.index).getPosition()
    prevGameState = self.getPreviousObservation()
    if myPos == self.start:
      self.foodHeld = 0
    elif len(self.getFood(prevGameState).asList()) - len(self.getFood(gameState).asList()) > 0:
      self.foodHeld += 1

    # If our score increases, we know we banked some enemy pellets, so reset foodHeld
    if prevGameState != None and self.getScore(gameState) > self.getScore(prevGameState):
      self.foodHeld = 0

    # You can profile your evaluation time by uncommenting these lines
    # start = time.time()
    values = [self.evaluate(gameState, a) for a in actions]
    # print 'eval time for agent %d: %.4f' % (self.index, time.time() - start)

    maxValue = max(values)
    bestActions = [a for a, v in zip(actions, values) if v == maxValue]

    # If we have multiple actions of the same maximum value, pick a random one.
    return random.choice(bestActions)

  def getFeatures(self, gameState, action):
    features = util.Counter()
    successor = self.getSuccessor(gameState, action)
    foodList = self.getFood(successor).asList()
    myPos = successor.getAgentState(self.index).getPosition()

    features['successorScore'] = -len(foodList)

    # Code modified from project 1 search tasks
    # @Author Liam - s3372913
    # A modified DFS, looking for cycles.
    # If we can't find a cycle to our start sate along a certain path, we have to be going into a dead end.
    # If we avoid dead ends we won't get boxed in by enemy ghosts.
    # We can use this when we're being pursued and we're unsure about the risks of taking a certain path.
    #def DeadEndCheck(evaluatingState, currentState):
    #    from game import Directions
    #    from util import Stack
    #
    #    frontier = Stack()
    #    explored = []
    #
    #    frontier.push(evaluatingState)
    #
    #   while not frontier.isEmpty():
    #       state = frontier.pop()
    #
    #        if state not in explored:
    #            if state == currentState:
    #                return False
    #
    #            for legalAction in state.getLegalActions(self.index):
    #                newState = state.generateSuccessor(self.index, legalAction)
    #                frontier.push(newState)
    #            explored.append(state)
    #
    #    "We couldn't find our way back around to the current player pos"
    #    "We must be at a dead end because of this."
    #    return True

    # Compute distance to the nearest food
    if len(foodList) > 0: # This should always be True,  but better safe than sorry
      minDistance = min([self.getMazeDistance(myPos, food) for food in foodList])
      features['distanceToFood'] = minDistance

    # Track close enemies, avoid when in danger.
    # We focus on when we're holding food.
    visibleEnemies = [successor.getAgentState(i).getPosition() for i in self.getOpponents(successor)]
    features['enemyAvoidance'] = 0
    if len(visibleEnemies) > 0 and not all(enemy is None for enemy in visibleEnemies):
      closestEnemy = min([self.getMazeDistance(myPos, visibleEnemy) for visibleEnemy in visibleEnemies if visibleEnemy != None])
      if closestEnemy < 2 and self.foodHeld > 0:
        features['enemyAvoidance'] = closestEnemy

    # Track noisy enemy positions
    noisyEnemies = [successor.getAgentDistances()[i] for i in self.getOpponents(gameState)]
    #TODO Think of a good way to handle noisy positions.

    # Desire to return (related to amount of food currently held)
    if self.foodHeld >= 3:
      features['desireToReturn'] = self.getMazeDistance(myPos, self.start)
    else:
      features['desireToReturn'] = 0

    # Look for potential capsules to grab
    # BUG: Doesn't seem to work correctly
    capsules = self.getCapsules(successor)
    closestCapsule = min([self.getMazeDistance(myPos, capsule) for capsule in capsules]) if len(capsules) > 0 else 99
    if closestCapsule <= 3:
        features['powerCapsule'] = closestCapsule
    else:
        features['powerCapsule'] = 0

    return features

  def getWeights(self, gameState, action):
    weights={
      'successorScore': 100,
      'distanceToFood': -10,
      'enemyAvoidance': -1000,
      #'noisyDist': 1,
      'desireToReturn': -50,
      #'powerCapsule': -25
    }

    for key, value in weights.iteritems():
      weights[key] = value * DEBUG_SEED

    return weights

class DefensiveReflexAgent(ReflexCaptureAgent):
    """
    A reflex agent that keeps its side Pacman-free. Again,
    this is to give you an idea of what a defensive agent
    could be like.  It is not the best or only way to make
    such an agent.
    """
    def chooseAction(self, gameState):
        actions = gameState.getLegalActions(self.index)
        values = [self.evaluate(gameState,a) for a in actions]
        maxValue = max(values)
        bestActions = [a for a, v in zip(actions,values) if v == maxValue]
        return random.choice(bestActions)

    def getFeatures(self, gameState, action):
        features = util.Counter()
        successor = self.getSuccessor(gameState, action)
        myState = successor.getAgentState(self.index)
        myPos = myState.getPosition()
        initialPos = successor.getInitialAgentPosition(self.index)
        enemies = [successor.getAgentState(i) for i in self.getOpponents(successor)]
        invaders = [a for a in enemies if a.isPacman and a.getPosition() != None]
        centreOfBoard = (gameState.getWalls().width/2, gameState.getWalls().height/2) ## FIXME: fails if centre of board is a wall
        if centreOfBoard not in self.getLegalPositions(gameState):
            # find position closest to centre
            distances = []
            for position in self.getLegalPositions(gameState):
                distance = util.manhattanDistance(centreOfBoard,position)
                distances.append((distance,position))
            closest = min(distances, key=lambda x: x[0])
            centreOfBoard = closest[1]


        invaderPresence = False


        # Computes distance to closest invader, within 5 tiles
        if len(invaders) > 0:
            dists = [self.getMazeDistance(myPos, a.getPosition()) for a in invaders]
            features['invaderDistance'] = min(dists)
            invaderPresence = True


        # Compute location of invader based on where food has been eaten
        if len(invaders) == 0:
            prevState = self.getPreviousObservation()
            currentState = self.getCurrentObservation()
            if prevState != None:
                previousFoodList = self.getFoodYouAreDefending(prevState).asList()
                currentFoodList = self.getFoodYouAreDefending(currentState).asList()

                if len(previousFoodList) > len(currentFoodList):
                    # Some food has been eaten. Find location where food has
                    # disappeared
                    invaderPresence = True
                    difference = list(set(previousFoodList) - set(currentFoodList))
                    # print "difference: ", difference
                    pos = difference[0] # difference could have more than one item if several invaders at once eating food
                    distance = self.getMazeDistance(myPos, pos)
                    features['searchForInvader'] = distance





        # Calulating closest enemy if there are no invaders
        # Must be within 5 tiles
        if not invaderPresence:
            actualEnemyDists = [self.getMazeDistance(myPos, a.getPosition()) for a in enemies if a.getPosition() != None]
            if actualEnemyDists:
                features['enemyDistance'] = min(actualEnemyDists)

            # TESTING: Calculate if food is close when no enemies are near
            else:
                GET_FOOD_THRESHOLD = 4
                foodList = self.getFood(successor).asList()
                closestFood = min([self.getMazeDistance(myPos, food) for food in foodList])
                if closestFood < GET_FOOD_THRESHOLD:
                    print "snatching food"
                    features['snatchFood'] = closestFood

        # Go towards middle of our 'zone' to try and find invader
        if invaderPresence:
            x,y = centreOfBoard
            newPos = x/2,y/2
            # Check the value is valid
            if newPos not in self.getLegalPositions(gameState):
                # find position closest to centre
                distances = []
                for position in self.getLegalPositions(gameState):
                    distance = util.manhattanDistance(newPos,position)
                    distances.append((distance,position))
                closest = min(distances, key=lambda x: x[0])
                newPos = closest[1]

            distanceFromMiddle = self.getMazeDistance(myPos, newPos)
            features['midZoneDistance'] = distanceFromMiddle


        # Computes most likely position of closest enemy
        if invaderPresence:
            # First get 'raw' noisy distances
            noisyEnemyDists = self.getEnemyNoisyDistances(gameState)
            noisyDistances = gameState.getAgentDistances()
            ### FIXME: probabilities not being calculated correctly ###
            # Compute probability for each legal position on board
            # allPossiblePositions = util.Counter()
            # actualDistribution = util.Counter()
            # for agent in self.getOpponents(gameState):
            #     for pos in self.getLegalPositions(gameState):
            #         trueDistance = self.getMazeDistance(myPos, pos)
            #         probability = gameState.getDistanceProb(trueDistance, noisyDistances[agent])
            #         allPossiblePositions[pos] = probability
            #     actualDistribution[agent] = allPossiblePositions
            #
            # print "distribution: ", actualDistribution
            # ## DEBUGGING
            # self.displayDistributionsOverPositions(actualDistribution)
            # ##
            #     # enemyPositions[agentDistance] = \
            #         # allPossiblePositions[allPossiblePositions.argMax()]
            # # print "most likely positions: ", enemyPositions
            # closestGuess = min(enemyPositions)


            features['noisyDistance'] = min(noisyEnemyDists)




        # Computes whether we're on defense (1) or offense (0)
        features['onDefense'] = 1
        if myState.isPacman:
             features['onDefense'] = 0

        # Computes number of current invaders we can see
        features['numInvaders'] = len(invaders)


        if action == Directions.STOP:
            features['stop'] = 1

        rev = Directions.REVERSE \
            [gameState.getAgentState(self.index).configuration.direction]
        if action == rev:
            features['reverse'] = 1

        # Compute if currently scared or not
        if myState.scaredTimer > 0:
            features['scared'] = myState.scaredTimer



        # If your teammate is also currently defending, stay away from them to cover larger area
        # team = self.getTeam(gameState)
        # for friend in team:
        #     if friend != self.index:
        #         teammate = friend
        # friendlyState = successor.getAgentState(teammate)
        # if not friendlyState.isPacman:
        #     friendPos = friendlyState.getPosition()
        #     distanceFromFriend = self.getMazeDistance(myPos, friendPos)
        #     features['friendDistance'] = distanceFromFriend


        # Stay away from starting position, encourage ghost to stay near border
        # distanceFromStart = self.getMazeDistance(myPos, initialPos)
        # features['startDistance'] = distanceFromStart


        # Favour staying in the centre of the board, only if no invaders
        if not invaderPresence:
            distanceFromCentre = self.getMazeDistance(myPos, centreOfBoard)
            features['centreDistance'] = distanceFromCentre

        return features

    def evaluate(self, gameState, action):
        """
        Computes a linear combination of features and feature weights
        """
        features = self.getFeatures(gameState, action)
        weights = self.getWeights(gameState, action)
        # print "features: ", features
        # print "weights: ", weights
        # print "action: ", action
        # print "features * weights: ", features*weights
        # print "\n"
        return features * weights

    def getWeights(self, gameState, action):
        weights={
            'numInvaders': -1000,
            'onDefense': 1000, # cross over score
            'invaderDistance': -10000, # go towards invaders (closest)
            # 'enemyDistance': -500, # go towards any enemy (closest)
            'noisyDistance': -800, # go towards probable location (closest)
            'snatchFood': -1000, # go towards food when no enemies
            'stop': -100,
            'reverse': -2,
            'scared': -100,
            'searchForInvader': -100,
            # 'startDistance': 10, # stay away from start
            # 'friendDistance': 10, # stay away from friend ##COULD BE IMPROVED##
            'centreDistance': -1, # go towards centre
            'midZoneDistance': -100 # go towards middle of zone
        }

        #for key, value in weights.iteritems():
        #    weights[key] = value * DEBUG_SEED

        return weights
